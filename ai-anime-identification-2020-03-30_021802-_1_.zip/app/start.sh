python app.py
